

==README $safeprojectname$

Goal :  Auto Generated and Auto Published to NuGet.Org with automatic versionning.

