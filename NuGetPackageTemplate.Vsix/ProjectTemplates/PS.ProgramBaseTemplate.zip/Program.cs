﻿using System;

using PS.Common.Core;

using PS;

using System.Collections.Generic;
$if$ ($targetframeworkversion$ >= 3.5)using System.Linq;
$endif$using System.Text;

namespace $safeprojectname$
{
	
   class Program : ProgramBase<Program>
{
    static void Main(string[] args)
    {
        //Goal: generate what is needed for GDS Identifier data.
        //ex.  gidug -new -qr which print a new Idug in the console, generate a QR and open the file
        // -n -qr -o
        BaseInitialized += Program_BaseInitialized;
        BaseInitializationStarting += Program_BaseInitializationStarting;
        InitializeBase("", "JG", "2018-01-01", args, "Goal:  .",
          $@"
-help
");

    }
    private static void Program_BaseInitializationStarting(object sender, CLIArgsEventArgs e)
    {
      //Executed when base init starts

    }

    private static void Program_BaseInitialized(object sender, EventArgs e)
    {

      //Executed when  base init ends
    }

}
}